"""words.py
author: Lauren Olson
This program contains one function, most_common, and a class WordVectors. The most common
function takes a file of words and their parts of speech, separated by a forward slash and
, and counts the most commonly occurring words, parts of speech, filtering by inputed regular expressions.
The WordVectors class has two functions: average_vector and most_similar which find the element wise average of vectors
based on their inputed words and finds a list of the most similar words to a word, respectively. 
"""
from typing import List, Text, Tuple, Dict
from collections import Counter
import numpy as np
import sklearn.metrics
import heapq
import re


def most_common(word_pos_path: Text,
                word_regex=".*",
                pos_regex=".*",
                n=10) -> List[Tuple[Text, int]]:
    """Finds the most common words and/or parts of speech in a file.
    
    :param word_pos_path: The path of a file containing part-of-speech tagged
    text. The file should be formatted as a sequence of tokens separated by
    whitespace. Each token should be a word and a part-of-speech tag, separated
    by a slash. For example: "The/at Hartsfield/np home/nr is/bez at/in 637/cd
    E./np Pelham/np Rd./nn-tl Aj/nn ./."

    :param word_regex: If None, do not include words in the output. If a regular
    expression string, all words included in the output must match the regular
    expression.
    
    :param pos_regex: If None, do not include part-of-speech tags in the output.
    If a regular expression string, all part-of-speech tags included in the
    output must match the regular expression.
        
    :param n: The number of most common words and/or parts of speech to return.

    :return: A list of (token, count) tuples for the most frequent words and/or
    parts-of-speech in the file. Note that, depending on word_regex and
    pos_regex (as described above), the returned tokens will contain either
    words, part-of-speech tags, or both.
    """
    #read file into an array 
    file = open(word_pos_path, "rt") 
    file_string = file.read(); 
    file_array = file_string.split() 
    
    #create a dictionary of tokens to counts
    full_dict = Counter(file_array)

    #create dictionaries of parts of speech to counts and words to counts 
    word_array = []
    pos_array = []
    for token in file_array:
        array = token.split("/")
        if(len(array) == 3): #rule for "1-1/2-story/nn" and "4-1/2%/nn"
            word_array.append(array[0] + array[1])
            pos_array.append(array[2])
        else:
            word_array.append(array[0])
            pos_array.append(array[1])
    pos_dict = Counter(pos_array)
    word_dict = Counter(word_array)

    retList = [] 
    
    #if only words will be returned, add the most common words
    #to the return list
    if(word_regex != None and pos_regex == None):
        for key in word_dict.keys():
            original_key = key
            key = _regex_helper(key, word_regex)
            if(key != None):
                retList.append((key, word_dict[original_key]))
                
    # else if only parts of speech are returned, add the most common 
    #parts of speech to the return list
    elif(word_regex == None and pos_regex != None):
        for key in pos_dict.keys():
            original_key = key
            key = _regex_helper(key, pos_regex)
            if(key != None):
                retList.append((key, pos_dict[original_key]))
                
    #else if both words and parts of speech will be returned, return 
    #them based on their most common tokens
    elif(word_regex != None and pos_regex != None):
        for key in full_dict.keys():
            original_key = key
            word_key = _regex_helper(key.split("/")[0], word_regex)
            pos_key = _regex_helper(key.split("/")[1],  pos_regex)
            if(pos_key != None and word_key != None):
                new_key = word_key + "/" + pos_key
                retList.append((new_key, full_dict[original_key])) 
                
    #return the list based on the number stored in the tuple
    return heapq.nlargest(n , retList , key=lambda x: x[1]) 

def _regex_helper(key, regex):
    """This function handles the regular expressions for the most_common function.
    :param key: The string from the file that needs to be checked for a regex match.
    :param regex: The regular expression, provided by the test cases, to compare the key to.
    """
    word_match = re.match(regex, key)
    if(word_match != None):
        key = word_match.group(0)
    else:
        return None
    return key

class WordVectors(object):
    def __init__(self, word_vectors_path: Text):
        """Reads words and their vectors from a file.
        :param word_vectors_path: The path of a file containing word vectors.
        Each line should be formatted as a single word, followed by a
        space-separated list of floating point numbers. For example:
        the 0.063380 -0.146809 0.110004 -0.012050 -0.045637 -0.022240
        """
        file = {}
        f  = open(word_vectors_path)
        #creates a mapping between the word and its vector, which is stored as a list
        for line in f:
            sub_array = line.split(None, 1)
            nums_list = sub_array[1].split()
            nums_list = list(map(float, nums_list))
            file[sub_array[0]] =  nums_list
        self.file = file
        
    def average_vector(self, words: List[Text]) -> np.ndarray:
        """Calculates the element-wise average of the vectors for the given
        words.

        For example, if the words correspond to the vectors [1, 2, 3] and
        [3, 4, 5], then the element-wise average should be [2, 3, 4].
        //have an array of the arrays and then take the array average with numpy.mean
        //we want to construct 
        :param words: The words whose vectors should be looked up and averaged.
        :return: The element-wise average of the word vectors.
        """
        average_array = []
        count = 0
        for i in range(0, len(self.file[words[0]])):
            sub_array = []
            sub_count = 0
            for word in words:
                sub_array.insert(sub_count, self.file[word][i])
                sub_count += 1
            average_array.insert(count, np.average(sub_array))
            count += 1
        return np.array(average_array)

    def most_similar(self, word: Text, n=10) -> List[Tuple[Text, int]]:
        """Finds the most similar words to a query word. Similarity is measured
        by cosine similarity (https://en.wikipedia.org/wiki/Cosine_similarity)
        over the word vectors.
        :param word: The query word.
        :param n: The number of most similar words to return.
        :return: The n most similar words to the query word.
        """
        return_list = []
        vector1 = np.array([self.file[word]])
        for key in self.file.keys():
            if(key != word):
                vector2 = np.array([self.file[key]])
                return_list.append((key, sklearn.metrics.pairwise.cosine_similarity(vector1, vector2)))
        return heapq.nlargest(n,return_list, key=lambda x: x[1])
    
